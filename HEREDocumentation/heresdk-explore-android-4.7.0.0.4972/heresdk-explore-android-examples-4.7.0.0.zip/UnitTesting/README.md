The UnitTesting example app shows how the HERE SDK can be mocked in unit tests.

Build instructions:
-------------------

1) Copy the AAR and mock JAR files of the HERE SDK for Android to your app's `app/libs` folder.

Note: If your AAR/JAR version are different than the version shown in the _Developer's Guide_, you may need to adapt the source code of the example app.

2) Open Android Studio and sync the project.
3) Open file TestBasicTypes.java and run unit tests from it.
