# Migration Guide

This guideline provides a set of steps to migrate from another HERE SDK edition to the _HERE SDK for Android (Navigate Edition)_.

When you plan to migrate from a different SDK like Mapbox or Google Maps it is recommended to take a look at the [Key Concepts](key-concepts.md) section. Here you can find the most common concepts that are unified across the _Lite_, _Explore_ & _Navigate Editions_. The differences between these editions are listed in the [Overview](../README.md) section of this guide.

> **At a glance**
> - Within the _Lite_, _Explore_ & _Navigate Editions_ it is straight-forward to switch from one platform to another: All available platforms - Android, iOS and Flutter - share the same native code base under the hood. This way the available HERE SDK features behave consistently across platforms while being faithfully adapted to the individual platform conventions. Nevertheless, different features may result in different APIs and behavior - for example, the **HERE Rendering Engine** behaves different than the **Lite Renderer** and thus, the `MapViewLite` component contains slightly different APIs. More details on the main differences are shown below.
>
> - The _Starter_ and _Premium Editions_ share a different technology stack. As a result, most APIs, concepts and behaviors differ from the new _Lite_, _Explore_ & _Navigate Editions_. This may require a more coherent migration strategy. The possible steps are shown below. Note that the _Starter Edition_ is deprecated.

## Overview

Unless for very small projects, migrating an app from one edition to another requires time and may introduce breaking changes to your customers. To minimize the effort, we recommend an incremental approach:

1. Before you start, learn more about the availability of the features. Please consult the "Feature comparison for the HERE SDK" list you can find on the [HERE SDK](https://developer.here.com/products/here-sdk) launch page. If a feature is not available for the targeted edition, consult your HERE representative. It may be already planned for one of the next regular releases.

2. Check the available plans for the new edition. You can freely start using the HERE SDK with the [Freemium](https://developer.here.com/blog/our-here-freemium-developer-plan-in-detail) plan. An overview of the available plans can be found on the [pricing page](https://developer.here.com/pricing). More details on the plans can be found in our [FAQs](https://developer.here.com/faqs#licensing--terms).

3. Request a new set of credentials from your HERE representative. Credentials are _not_ interchangeable between editions. For now, the _Navigate Edition_ is only available upon request.

4. Start to migrate. This is covered in more detail in the sections below.

## Migration Strategies

Depending on the complexity of your app, it may not be necessary to start from scratch. Instead, consider to create a copy of your existing project and start to migrate the features step-by-step.

There are several different strategies possible to successfully complete the migration of your app. One possible strategy could be the following:

1. Deintegrate the old SDK library first.

2. Then integrate the new SDK library by following the [Get Started](quick-start.md) section.

3. Finally, fix the remaining compile errors of your legacy code by adapting to the new APIs and start testing. Unit and integration tests may help.

> Note: For larger projects it may be feasible to create isolated projects that allow you to test your code with the new SDK in advance. This allows you to see if the new behavior matches your expectations - _before_ all desired features are migrated.

As a tip, it may help if your code is implemented against interfaces to keep your code decoupled from a specific library. This way it will be easier to comment out legacy code and replace it featurewise instead of producing countless compile errors once a library is deintegrated.

> Warning: It is not possible to integrate two different editions into the same app. Therefore, some libraries or classes may cause duplication errors at compile time.

Below you can find more details on the needed migration steps per edition.

## Migrate from Explore to Navigate Edition

No migration work is needed. The _Explore Edition_ is a subset of the _Navigate Edition_ and thus the code will compile and behave as before. You only need to replace the library inside the app's libs folder and insert your new credentials into the `AndroidManifest.xml`. Request new credentials from your HERE representative. For now, the _Navigate Edition_ is only available upon request.

## Migrate from Lite to Navigate Edition

All map view related code may need adaptation, as the _Lite Edition_ uses a light-weighted map renderer. When switching to the _Navigate Edition_, the `MapViewLite` must be replaced with a `MapView` to benefit from the powerful features of the **HERE Rendering Engine**. The good news is that all other code can stay the same as it already shares the same native code base with the _Navigate Edition_.

1. Start by replacing the `MapViewLite` with `MapView`.

2. Follow the [Get Started](quick-start.md) guide to properly load the map view. It's almost identical to the _Lite Edition_.

3. Adapt the namespace in your XML layoutfile:

Replace

```xml
<com.here.sdk.mapviewlite.MapViewLite
   android:id="@+id/map_view"
   android:layout_width="match_parent"
   android:layout_height="match_parent">
</com.here.sdk.mapviewlite.MapViewLite>
```

with

```xml
<com.here.sdk.mapview.MapView
   android:id="@+id/map_view"
   android:layout_width="match_parent"
   android:layout_height="match_parent">
</com.here.sdk.mapview.MapView>
```

4. Notice that the `MapStyle` schemes available for the _Lite Edition_ are replaced by `MapScheme` styles. The `NORMAL_DAY` and `SATELLITE` styles are available for both editions. Consult the _API Reference_ to see the additional predefined map styles that are available for the _Navigate Edition_.

5. See that custom map styles use a different style format and are not interchangeable. Read the [Custom Map Styles](custom-map-styles.md) section to learn more about the advanced capabilities of the _HERE Style Editor_.

6. Consult the [Map Items](map-items.md) section to grab ready-to-use code snippets and to learn how to add items to the map view. The _Navigate Edition_ supports the same set of map items as the _Lite Edition_. `MapOverlay` views have been renamed to `MapViewPin`. Note that a few features that are available in the _Lite Edition_ are not yet available for the _Navigate Edition_, for example, a rotation of `MapMarker` items is not yet supported. The above section provides an overview of what is currently available.

7. Read the [Camera](camera.md) section to see the differences and advanced capabilities available for the _Navigate Edition_. The `MapCamera` allows full 3D camera control and many more exciting features.

> Note that the _Navigate Edition_ also provides zoom levels, but the actual level of detail may differ. The map projection of the _Navigate Edition_ uses globe projection instead of mercator projection. In addition, the _Navigate Edition_ uses the distance to earth to position the camera above the map as this allows more precise results. To convert your existing _Lite_ zoom level values to distance in meters, you can use the following nearing formula:
>
> `double distanceToEarthInMeters = Math.pow(2, 16.251628683 - zoomlevelFromLite);`

To help you with migration, you can find the same set of [example apps](https://github.com/heremaps/here-sdk-examples/blob/master/examples/latest/lite/android) available for the _Lite Edition_ already ported to the _Navigate Edition_ on [GitHub](https://github.com/heremaps/here-sdk-examples/blob/master/examples/latest/navigate/android).

## Migrate from Premium to Navigate Edition

Unlike the other editions, the _Starter_ and _Premium Edition_ share a completely different technology stack and thus, the new SDK editions _Lite_, _Explore_ & _Navigate_ are completely built from scratch. This results in different APIs, concepts and behaviors.

As a result, this means that there is no 1:1 conversion possible. When planning to migrate, make sure to plan enough resources to test your app before & after the migration.

Follow the use cases described in this _Developer's Guide_ to get a first overview of the available  features and possible differences. Also, take a look at the [Key Concepts](key-concepts.md) section. Here you can find the most common concepts that are unified across the _Lite_, _Explore_ & _Navigate Editions_.

You can find a set of example apps available for the _Navigate Edition_ on [GitHub](https://github.com/heremaps/here-sdk-examples/blob/master/examples/latest/navigate/android).

Since the _Starter Edition_ is deprecated, it is not explicitly included in this migration guide. However, most of the sections below can be also applied when migrating from _Starter_ to _Navigate Edition_. Similar to the _Explore Edition_ that replaces the _Starter Edition_, the _Starter Edition_ can be seen as a subset of the _Navigate Edition_.

> #### Note::Important
> This migration guide does not provide a 1:1 comparison between the _Premium Edition_ and the _Navigate Edition_ due to the complexity and divergence of both editions. Instead, the focus lies on general concepts and patterns - as well as the differences - to provide a rough guideline to get started.
>
> - In most cases, it may be easier to remove the old code completely and insert the new code from the _Navigate Edition_ featurewise - instead of converting the code line-by-line.
>
> - For this, the best approach may be to look for suitable code snippets you can take from the various use cases shown in this _Developer's Guide_ or on [GitHub](examples.md). See also the possible _Migration Strategies_ described above.

### Why Should I Migrate?

The new _Lite_, _Explore_ & _Navigate Editions_ are built completely from scratch to ensure support for the latest HERE technology stack. In comparison to the _Starter_ and _Premium Editions_ you gain the following benefits:

- Consume data from the [HERE platform](https://www.here.com/platform) incorporating microservices and highly modularized components enabling most seamless switches from one edition to another.
- Optimized size and performance.
- Advanced map rendering and customization capabilities.
- Freshest map data with weekly map updates.
- Leverage new HERE platform services that are only supported with the new editions.

### Feature Lists

Before you start, learn more about the availability of the individual features for each edition. Please consult the "Feature comparison for the HERE SDK" list you can find on the [HERE SDK](https://developer.here.com/products/here-sdk) launch page. In addition, compare the more granular [Navigate feature list](about.md) with the [Premium feature list](https://developer.here.com/documentation/android-premium/3.16/dev_guide/topics/use-cases.html), that are available as part of the respective user guides.

> If a feature is not available for the _Navigate Edition_, consult your HERE representative. It may be already planned for one of the next regular releases.

### Credentials

Start by acquiring new credentials. For the _Navigate Edition_ you need to contact your HERE representative to generate a set of evaluation credentials.

In contrast to the _Premium Edition_, the _Navigate Edition_ uses a different type of credentials. APP ID, TOKEN and LICENSE ID are not needed, instead you need two strings:

- ACCESS KEY ID
- ACCESS KEY SECRET

The acquired credentials can be reused for the _Lite_ and _Explore Editions_ regardless of the platform - furthermore, you can use these credentials for more than one app. For example, they will work with all example apps you can find on [GitHub](examples.md).

> **Note:** Unlike for the _Premium Edition_, these credentials are _not_ tied to the package name or the application ID of your app, but to the account used to obtain the credentials. This makes it possible to use the same set of credentials for multiple apps.

### Artifactory Support

The _Lite_, _Explore_ & _Navigate Editions_ do not yet provide artifactory support. This means that you must manually download and integrate the HERE SDK library (AAR) as described [here](quick-start.md).

### Engines

Most notably, all features within the _Navigate Edition_ are built around _engines_. To look for certain features, it's best start finding the related engine in the _API Reference_ and consult the related chapter within this user guide to get an overview.

- `SearchEngine`: Includes all functionality to search for places, suggestions and locations including geocoding and reverse geocoding.
- `RoutingEngine`: Allows to calculate routes including various options and transport types.
- `LocationEngine`: An advanced HERE positioning solution.
- `ConsentEngine`: A supportive engine that helps to aggregate the user's consent before using, for example, the `LocationEngine`.
- `VenueEngine`: A specialized engine to support the integration of private venues into your apps.
- `SDKNativeEngine`: Normally not needed, but this engine allows to set credentials programmatically and allows a few other advanced settings.
- `Navigator`: Although not having 'engine' in its name, this class acts as an engine and controls all functionality around turn-by-turn navigation.

All map related features are grouped around the `MapView` class. Note that you can fully operate the _Navigate Edition_ in a _headless_ mode without showing a map.

### Map View

The _Navigate Edition_ features an advanced _HERE Rendering Engine_ that offers visually appealing true 3D maps that provide highly performant map rendering tailored for high-end devices. Take a look at the [Key Concepts](key-concepts.md) section for more details.

- To integrate the `MapView`, follow the [Get Started](quick-start.md) guide to properly load the map view.

- Consult the _API Reference_ to see the available predefined `MapScheme` styles that are available for the _Navigate Edition_.

- Custom map styles use a different style format than the _Premium Edition_ and are not interchangeable. Read the [Custom Map Styles](custom-map-styles.md) section to learn more about the advanced capabilities of the _HERE Style Editor_.

- Read the [Map Items](map-items.md) section to grab ready-to-use code snippets and to learn how to add items to the map view. The above section provides an overview of what is currently available.

- Read the [Camera](camera.md) section to get an overview of the differences and advanced capabilities of the _Navigate Edition_. The `MapCamera` allows full 3D camera control and many more exciting features. Note that the _Navigate Edition_ also provides zoom levels, but the actual level of detail may differ. In addition, the _Navigate Edition_ uses the distance to earth to position the camera above the map as this allows more precise results.

To complement this section, read also the [Gestures](gestures.md) & [Traffic](traffic.md) sections to know about the available map view behavior. Certain other map features like _marker clustering_, _custom raster tiles_, _3D landmarks_ or _animations_ are _not_ yet available.

To add customized zoom in/out map animations you can overwrite the `DOUBLE_TAP` and `TWO_FINGER_TAP` gestures:

```java
mapView.getGestures().disableDefaultAction(GestureType.DOUBLE_TAP);
mapView.getGestures().disableDefaultAction(GestureType.TWO_FINGER_TAP);

mapView.getGestures().setDoubleTapListener(new DoubleTapListener() {
    @Override
    public void onDoubleTap(@NonNull Point2D touchPoint) {
        // Start your custom zoom in animation.
    }
});

mapView.getGestures().setTwoFingerTapListener(new TwoFingerTapListener() {
    @Override
    public void onTwoFingerTap(@NonNull Point2D touchCenterPoint) {
        // Start your custom zoom out animation.
    }
});
```

In the [Gestures](gestures.md) section you can find a tutorial how this can be implemented.

### Places

With the _Navigation Edition_ you can access almost the same backend services as with the _Premium Edition_. To get started, consult the [Search](search.md) section.

Instead of using separate request classes like `SearchRequest` or `ExploreRequest`, the _Navigate Edition_ combines all features into a single `SearchEngine`. This includes suggestions, geocoding and reverse geocoding and other advanced search features like _search along a route_.

With the `SearchEngine` you can initiate different asynchronous requests by calling the dedicated (overloaded) methods. For example, to fetch places for a category, use the following overloaded `search()` method:

```java
private void searchForCategories() {
    List<PlaceCategory> categoryList = new ArrayList<>();
    categoryList.add(new PlaceCategory(PlaceCategory.EAT_AND_DRINK));
    categoryList.add(new PlaceCategory(PlaceCategory.SHOPPING_ELECTRONICS));
    CategoryQuery categoryQuery = new CategoryQuery(categoryList, new GeoCoordinates(52.520798, 13.409408));

    int maxItems = 30;
    SearchOptions searchOptions = new SearchOptions(LanguageCode.EN_US, maxItems);

    searchEngine.search(categoryQuery, searchOptions, new SearchCallback() {
        @Override
        public void onSearchCompleted(SearchError searchError, List<Place> list) {
            if (searchError != null) {
                // An error happened ...
                return;
            }

            // If error is null, list is guaranteed to be not empty.
            for (Place searchResult : list) {
                String addressText = searchResult.getAddress().addressText;
                Log.d(TAG, addressText);
            }
        }
    });
}
```

Note that _place discovery requests_ that contain a list of links to additional places resources with detailed information about that place including ratings, images, reviews, editorials, and owner content are not yet supported.

### Directions

The directions feature allows developers to define and display routes between a start and a destination point within their application. It supports many options such as road avoidance options and transport type for car, pedestrian and truck routing.

Via the dedicated `RoutingEngine` you can access all available features. The example below shows how a route can be calculated with the _Navigate Edition_:

```java
Waypoint startWaypoint = new Waypoint(startGeoCoordinates);
Waypoint destinationWaypoint = new Waypoint(destinationGeoCoordinates);

List<Waypoint> waypoints =
        new ArrayList<>(Arrays.asList(startWaypoint, destinationWaypoint));

routingEngine.calculateRoute(
        waypoints,
        new CarOptions(),
        new CalculateRouteCallback() {
            @Override
            public void onRouteCalculated(@Nullable RoutingError routingError, @Nullable List<Route> routes) {
                if (routingError == null) {
                    Route route = routes.get(0);
                    // ...
                } else {
                    showDialog("Error while calculating a route:", routingError.toString());
                }
            }
        });
```

The [Directions](routing.md) section provides an overview of the capabilities and how to calculate other type of routes with the _Navigate Edition_.

Note that the following features are not yet supported:

- Bicycle Routing
- Transit Routing
- Indoor Venue Routing

### Turn-by-Turn Navigation for Walking and Driving

The _Navigation Edition_ supports navigation on pedestrian, truck, and car routes. Using this feature, your app can check the current device position against a calculated route and get just-in-time navigational instructions. Both visual and audio instructions are supported. Currently, most visual information like road arrows must be added by the developer. For this you can use the icons available from the [MSDKUI open source library](https://github.com/heremaps/msdkui-android/tree/master/MSDKUIDemo/MSDKUIApp/src/main/res).

In contrast to the _Premium Edition_, the _Navigate Edition_ does not rely on a `PositioningManager` running behind the scenes. Instead you are free to feed locations from any source into the `Navigator`: This class bundles all available guidance functionality. It is the equivalent to Premium's `NavigationManager`.

With the dedicated `Navigator` class you can also track the current position and display it on the map without a calculated route.

Once you have set a location source and a route, the `Navigator` will send events about the progress along the route. For example, to know when a waypoint is reached, use the following snippet:

```java
navigator.setMilestoneReachedListener(new MilestoneReachedListener() {
    @Override
    public void onMilestoneReached(Milestone milestone) {
        if (milestone.waypointIndex != null) {
            Log.d(TAG, "A user-defined waypoint was reached, index of waypoint: " + milestone.waypointIndex);
            Log.d(TAG,"Original coordinates: " + milestone.originalCoordinates);
        } else {
            // For example, when transport mode changes due to a ferry.
            Log.d(TAG,"A system defined waypoint was reached at " + milestone.mapMatchedCoordinates);
        }
    }
});
```

The _Navigation Editon_ also supports a simulation mode. Instead of calling `navigationManager.simulate(route, speedInMetersPerSecond);` you use a separate `LocationSimulator` to generate `Location` updates. This allows better decoupling from navigation and the various available location sources.

The code below creates a new instance and allows a `Route` and `LocationSimulatorOptions` as parameter. The latter allows to set the desired speed settings:

```java
LocationSimulator locationSimulator;

try {
    locationSimulator = new LocationSimulator(route, locationSimulatorOptions);
} catch (InstantiationErrorException e) {
    throw new RuntimeException("Initialization of LocationSimulator failed: " + e.error.name());
}
```

By attaching a `LocationListener` to the `LocationSimulator` you can get notified on `Location` updates. Then you can feed them separately into the `Navigator`. This also makes Premium's `PositionSimulator` obsolete: Instead, use the `LocationSimulator` for any route simulation purposes. The `LocationSimulator` also supports playback of GPX log traces.

- To support text-to-speech voice navigation there is _no_ separate `VoiceCatalog` download needed. For your convenience, these assets are now integrated into the HERE SDK library.

- Note that traffic-aware routing is enabled by default and the current traffic delay can be retrieved from the `RouteProgress` event during turn-by-turn navigation.

A more detailed introduction to the various navigation features can be found in the [Navigation](navigation.md) section.

### 3D Venues

In comparison to the _Premium Edition_, you can only integrate private venues with the _Navigate Edition_. This can include shopping malls, airports, train stations and other buildings. You can search for a venue, open a venue, and get a notification when a venue is visible in the map viewport.

Public venues are already deprecated for the _Premium Edition_ and they are not availble for the _Navigate Edition_. If you are a venue owner and want HERE to continue to maintain and surface your venue in our offerings, or those of our partners, contact us at [venues.support@here.com](mailto:venues.support@here.com).

### Positioning

The _Navigate Edition_ allows applications to choose from two different location sources. Similar to the _basic positioning_ feature available for the _Premium Edition_, you can use any native location information provided by the Android platform.

Use the following method to convert `android.location.Location` instances to the `Location` class consumed by the HERE SDK to cover the most common fields:

```java
private Location convertLocation(android.location.Location nativeLocation) {
    GeoCoordinates geoCoordinates = new GeoCoordinates(
            nativeLocation.getLatitude(),
            nativeLocation.getLongitude(),
            nativeLocation.getAltitude());

    Location location = new Location(geoCoordinates, new Date());

    if (nativeLocation.hasBearing()) {
        location.bearingInDegrees = (double) nativeLocation.getBearing();
    }

    if (nativeLocation.hasSpeed()) {
        location.speedInMetersPerSecond = (double) nativeLocation.getSpeed();
    }

    if (nativeLocation.hasAccuracy()) {
        location.horizontalAccuracyInMeters = (double) nativeLocation.getAccuracy();
    }

    return location;
}
```

Within the `Navigate Edition` _advanced positioning_ features are handled via the dedicated `LocationEngine`. This class replaces the `PositioningManager` as known from the _Premium Edition_.

The _advanced positioning_ capabilities of the _Navigate Edition_ are described in the [Get Locations](get-locations.md) section. Note that _offline network positioning_ as well as _indoor positioning_ are not yet available.

### Map Disk Cache

The _Navigate Edition_ allows you to set the map disk cache to another location such as an SD Card via the `SDKNativeEngine`. This is described in the [Key Concepts](key-concepts.md) section.

### Missing Features

In comparison to the _Premium Edition_, there are a few features that are not yet implemented for the _Navigate Edition_. This includes:

- LiveSight
- Fleet Telematics / Custom Routes
- Platform Data Extensions
- Toll Cost Extensions
- Electronic Horizon
- Custom Locations and Geometries
- Public Transit
- Bicycle routes and bicycle navigation
- Map marker clustering
- 3d landmarks
- Overlay raster tiles
- Map view animations
- Searchable traffic incidents

Note: For now, map view animations are only possible on app side. An example, how this can be implemented is shown in the _Camera_ example app, which is available on [GitHub](https://github.com/heremaps/here-sdk-examples).

Note: Traffic incident icons can be shown on the map view as a layer, but currently, the HERE SDK does not support to search for incident details.

If any of these features are critical for your app, consider _not_ migrating yet. However, this does not mean that all other features like positioning, directions or navigation provide feature parity. For a quick overview consult the above sections.
